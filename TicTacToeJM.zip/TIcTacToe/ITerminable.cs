﻿using System;

public interface ITerminable{
    public bool IsFinished();
}
